import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const ACTIONS = [
  { to: "/profile", label: "Complete Profile", text: "Add your education, skills and experience." },
  { to: "/resume", label: "Build Resume", text: "Create a resume from your profile." },
  { to: "/jobs", label: "Find Jobs", text: "Discover roles that match your skills." },
  { to: "/applications", label: "Application Tracker", text: "Track where you have applied." },
];

export default function Dashboard() {
  const { user } = useAuth();
  const completion = 0; // placeholder until the profile feature is built

  return (
    <div className="container section">
      <h1>Welcome, {user.name}</h1>

      <div className="card progress-card">
        <div className="progress-head">
          <strong>Profile completion: {completion}%</strong>
        </div>
        <div className="progress" role="progressbar" aria-valuenow={completion} aria-valuemin="0" aria-valuemax="100">
          <div className="progress-bar" style={{ width: `${completion}%` }} />
        </div>
      </div>

      <div className="grid">
        {ACTIONS.map((a) => (
          <div className="card" key={a.to}>
            <h3>{a.label}</h3>
            <p>{a.text}</p>
            <Link to={a.to} className="btn btn-outline btn-sm">{a.label}</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
