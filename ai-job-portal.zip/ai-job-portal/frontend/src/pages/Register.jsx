import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import FormField from "../components/FormField.jsx";
import { getErrorMessage } from "../services/api.js";
import { registerUser } from "../services/authService.js";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Returns an object like { email: "Enter a valid email" } (empty object = all good)
function validate({ name, email, password, confirmPassword }) {
  const errors = {};
  if (name.trim().length < 2) errors.name = "Enter your full name (at least 2 characters).";
  if (!EMAIL_REGEX.test(email)) errors.email = "Enter a valid email address.";
  if (password.length < 8) errors.password = "Password must be at least 8 characters.";
  else if (!/[A-Za-z]/.test(password) || !/\d/.test(password))
    errors.password = "Password needs at least one letter and one number.";
  if (confirmPassword !== password) errors.confirmPassword = "Passwords do not match.";
  return errors;
}

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [loading, setLoading] = useState(false);

  // One handler for all inputs: uses the input's "name" to update the right field
  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    setServerError("");
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return; // stop if there are errors

    setLoading(true);
    try {
      await registerUser({ name: form.name.trim(), email: form.email.trim(), password: form.password });
      // Send the user to login with a success message
      navigate("/login", { state: { message: "Account created! Please log in." } });
    } catch (err) {
      setServerError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit} noValidate>
        <h1>Create your account</h1>
        <p className="muted">Start building your resume and tracking jobs.</p>

        {serverError && <div className="alert alert-error" role="alert">{serverError}</div>}

        <FormField label="Full name" id="name" value={form.name} onChange={handleChange}
          error={errors.name} autoComplete="name" placeholder="Jane Doe" />
        <FormField label="Email" id="email" type="email" value={form.email} onChange={handleChange}
          error={errors.email} autoComplete="email" placeholder="you@example.com" />
        <FormField label="Password" id="password" type="password" value={form.password}
          onChange={handleChange} error={errors.password} autoComplete="new-password"
          placeholder="At least 8 characters, letters and numbers" />
        <FormField label="Confirm password" id="confirmPassword" type="password"
          value={form.confirmPassword} onChange={handleChange} error={errors.confirmPassword}
          autoComplete="new-password" />

        <button className="btn btn-primary btn-block" disabled={loading}>
          {loading ? "Creating account..." : "Register"}
        </button>
        <p className="auth-switch">Already have an account? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
