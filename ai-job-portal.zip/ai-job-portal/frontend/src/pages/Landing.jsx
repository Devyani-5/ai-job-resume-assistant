import { Link } from "react-router-dom";

const FEATURES = [
  { icon: "📄", title: "AI Resume Builder", text: "Turn your experience into a clean, well-worded resume in minutes." },
  { icon: "🎯", title: "Job Matching", text: "See roles that fit your skills and interests, ranked by relevance." },
  { icon: "📊", title: "Skill Analysis", text: "Find out which skills you have and which ones employers want next." },
  { icon: "🗂️", title: "Application Tracker", text: "Keep every application, deadline and follow-up in one place." },
];

export default function Landing() {
  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <h1>Land your next job with a smarter search.</h1>
          <p className="hero-sub">
            AI Job &amp; Resume Assistant helps you build a strong resume, find roles that
            match your skills, and keep track of every application.
          </p>
          <div className="hero-actions">
            <Link to="/register" className="btn btn-primary btn-lg">Register</Link>
            <Link to="/login" className="btn btn-outline btn-lg">Login</Link>
          </div>
        </div>
      </section>

      <section className="container section">
        <h2>Everything you need in one place</h2>
        <div className="grid">
          {FEATURES.map((f) => (
            <article className="card" key={f.title}>
              <div className="card-icon" aria-hidden="true">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </article>
          ))}
        </div>
      </section>

      <footer className="footer">AI Job &amp; Resume Assistant - college project</footer>
    </>
  );
}
