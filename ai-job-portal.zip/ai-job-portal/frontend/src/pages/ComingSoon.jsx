import { Link } from "react-router-dom";

export default function ComingSoon({ title }) {
  return (
    <div className="container section center">
      <h1>{title}</h1>
      <p className="muted">Coming soon. We are still building this part.</p>
      <Link to="/dashboard" className="btn btn-primary">Back to dashboard</Link>
    </div>
  );
}
