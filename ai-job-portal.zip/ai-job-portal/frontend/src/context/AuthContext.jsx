// Keeps track of who is logged in and shares it with the whole app.
import { createContext, useContext, useEffect, useState } from "react";
import { TOKEN_KEY } from "../services/api.js";
import { getCurrentUser, loginUser } from "../services/authService.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true while we check a saved token

  // On first load: if a token is saved, ask the backend who it belongs to
  useEffect(() => {
    async function restoreSession() {
      if (!localStorage.getItem(TOKEN_KEY)) {
        setLoading(false);
        return;
      }
      try {
        const res = await getCurrentUser();
        setUser(res.data);
      } catch {
        localStorage.removeItem(TOKEN_KEY); // token expired or invalid
      } finally {
        setLoading(false);
      }
    }
    restoreSession();
  }, []);

  async function login(email, password) {
    const res = await loginUser({ email, password });
    // NOTE: localStorage is simple and fine for a college project. Production apps
    // often use httpOnly cookies, which JavaScript (and XSS attacks) cannot read.
    localStorage.setItem(TOKEN_KEY, res.data.access_token);
    setUser(res.data.user);
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
