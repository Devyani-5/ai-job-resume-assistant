// One shared Axios instance for all backend calls.
import axios from "axios";

export const TOKEN_KEY = "access_token";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  timeout: 15000,
});

// Before every request, attach the JWT (if we have one) as "Authorization: Bearer <token>"
api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turn any Axios error into a readable message for the UI
export function getErrorMessage(error) {
  if (!error.response) return "Cannot reach the server. Is the backend running?";
  const detail = error.response.data?.detail;
  if (typeof detail === "string") return detail;
  // FastAPI validation errors (422) come as a list of problems
  if (Array.isArray(detail)) {
    return detail.map((d) => d.msg.replace(/^Value error, /, "")).join(". ");
  }
  return "Something went wrong. Please try again.";
}

export default api;
