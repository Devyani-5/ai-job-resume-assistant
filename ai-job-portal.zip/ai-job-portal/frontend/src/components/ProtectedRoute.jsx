// Wraps pages that need login. Not logged in? Redirect to /login.
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import Spinner from "./Spinner.jsx";

export default function ProtectedRoute() {
  const { user, loading } = useAuth();
  if (loading) return <Spinner label="Checking your session..." />;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}
