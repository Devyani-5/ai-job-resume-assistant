// A label + input + error message, reused by the login and register forms.
export default function FormField({ label, id, error, ...inputProps }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} name={id} aria-invalid={!!error} className={error ? "has-error" : ""} {...inputProps} />
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}
