"""FastAPI application entry point."""
import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import models  # noqa: F401  (makes sure models are registered)
from app.database import Base, engine
from app.routes import auth

load_dotenv()

# Create the tables if they don't exist yet (fine for a college project;
# bigger projects use a migration tool such as Alembic)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI Job & Resume Assistant API", version="1.0.0")

# CORS: lets the React app (a different port) call this API from the browser
frontend_url = os.getenv("FRONTEND_URL", "http://localhost:5173")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[frontend_url, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)


@app.get("/")
def health_check():
    return {"status": "ok", "message": "AI Job & Resume Assistant API is running"}
