"""Database connection setup (SQLAlchemy + PostgreSQL)."""
import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# Read variables from the .env file into the environment
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set. Copy .env.example to .env and fill it in.")

# The engine manages the actual connection to PostgreSQL
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# Each request gets its own session (a "conversation" with the database)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

# All database models inherit from this Base class
Base = declarative_base()


def get_db():
    """FastAPI dependency: opens a session for a request and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
