from app.models.user import User  # noqa: F401  (imported so tables get registered)
