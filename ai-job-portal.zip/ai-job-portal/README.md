# AI Job & Resume Assistant (Stage 1)

A full-stack college project: landing page, registration, login (JWT) and a dashboard.

- **Frontend:** React + Vite, React Router, Axios
- **Backend:** Python, FastAPI, SQLAlchemy
- **Database:** PostgreSQL
- **Security:** bcrypt password hashing (passlib), JWT access tokens

```
ai-job-portal/
├── frontend/   React app (pages, components, services)
├── backend/    FastAPI app (models, schemas, routes, auth)
├── README.md
└── .gitignore
```

## 1. Install the tools (Windows)

1. **Python 3.10+** - https://www.python.org/downloads/ (tick "Add Python to PATH")
2. **Node.js 18+ (LTS)** - https://nodejs.org
3. **PostgreSQL 15+** - https://www.postgresql.org/download/windows/
   (remember the password you set for the `postgres` user)
4. **Git** - https://git-scm.com

## 2. Create the PostgreSQL database

Open **SQL Shell (psql)** from the Start menu (press Enter for the defaults and type your
`postgres` password), then run:

```sql
CREATE USER job_user WITH PASSWORD 'choose_a_strong_password';
CREATE DATABASE ai_job_portal OWNER job_user;
\q
```

The `users` table is created automatically the first time the backend starts.

## 3. Run the backend (Terminal 1)

```bat
cd ai-job-portal\backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Generate a secret key and paste it into `.env` as `JWT_SECRET_KEY`:

```bat
python -c "import secrets; print(secrets.token_hex(32))"
```

Edit `.env` (Notepad) so `DATABASE_URL` matches the user, password and database you created:

```
DATABASE_URL=postgresql://job_user:choose_a_strong_password@localhost:5432/ai_job_portal
```

> If your password contains special characters like `@` or `#`, URL-encode them (`@` -> `%40`).

Start the server:

```bat
uvicorn app.main:app --reload --port 8000
```

- API: http://localhost:8000
- Interactive docs (try endpoints in the browser): http://localhost:8000/docs

## 4. Run the frontend (Terminal 2)

```bat
cd ai-job-portal\frontend
npm install
copy .env.example .env
npm run dev
```

Open http://localhost:5173

## 5. Try it

1. Click **Register**, create an account.
2. You are sent to **Login**; log in.
3. You land on the **Dashboard**: "Welcome, your name".

## API endpoints

| Method | URL                   | Auth | Description                          |
|--------|-----------------------|------|--------------------------------------|
| POST   | `/api/auth/register`  | No   | Create a user (409 if email exists)  |
| POST   | `/api/auth/login`     | No   | Returns a JWT access token + user    |
| GET    | `/api/auth/me`        | JWT  | Returns the logged-in user           |

Test from Windows Command Prompt:

```bat
curl -X POST http://localhost:8000/api/auth/register -H "Content-Type: application/json" -d "{\"name\":\"Jane Doe\",\"email\":\"jane@example.com\",\"password\":\"secret123\"}"
curl -X POST http://localhost:8000/api/auth/login -H "Content-Type: application/json" -d "{\"email\":\"jane@example.com\",\"password\":\"secret123\"}"
curl http://localhost:8000/api/auth/me -H "Authorization: Bearer PASTE_TOKEN_HERE"
```

## Security notes

- Passwords are hashed with bcrypt; only `password_hash` is stored.
- Secrets live in `.env` files, which are listed in `.gitignore`. Only commit `.env.example`.
- The JWT is kept in `localStorage` for simplicity. Production apps often use httpOnly cookies.

## Troubleshooting

| Problem | Fix |
|---|---|
| `DATABASE_URL is not set` | You forgot `copy .env.example .env` in `backend`. |
| `password authentication failed` | Wrong user/password in `DATABASE_URL`. |
| `connection refused` on port 5432 | PostgreSQL service isn't running (Windows Services -> postgresql). |
| "Cannot reach the server" in the browser | Backend isn't running, or `VITE_API_URL` is wrong. |
| CORS error in browser console | `FRONTEND_URL` in `backend\.env` must match the address the frontend runs on. |
| `venv\Scripts\activate` blocked | Run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` in PowerShell, or use Command Prompt. |

## Next stages

Profile, AI resume builder, job matching with legitimate job-source APIs/links, skill analysis,
and the application tracker.
